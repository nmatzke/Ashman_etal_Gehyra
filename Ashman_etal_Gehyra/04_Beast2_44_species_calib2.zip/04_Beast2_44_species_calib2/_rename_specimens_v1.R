library(BioGeoBEARS)
library(XLConnect)	# for readWorksheetFromFile
library(stringr)	# for str_count


wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/04_Beast2_44_species/"
setwd(wd)


# Excel translation file
xlsfn = "rename.xlsx"

xls = readWorksheetFromFile(file=xlsfn, sheet="Sheet1", startRow=1)
head(xls)

oldnames = xls$old
newnames = xls$new

nexfn_orig = "treeLog.mcc_orig"
nexfn = "treeLog.mcc"

# Read the NEXUS file as text
tmplines = readLines(nexfn_orig)

tmplines[49]
for (i in 1:length(tmplines))
	{
	for (j in 1:length(oldnames))
		{
		tmplines[i] = gsub(pattern=oldnames[j], replacement=newnames[j], x=tmplines[i])
		}
	}
tmplines[49]


write(x=tmplines, file=nexfn, sep="\n")


