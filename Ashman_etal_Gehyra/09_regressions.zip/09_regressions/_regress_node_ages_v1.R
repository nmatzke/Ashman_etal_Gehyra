library(ape)

sourcedir = '/drives/Dropbox/_njm/'
source3 = '_genericR_v1.R'
source(paste(sourcedir, source3, sep=""))

source3 = '_R_tree_functions_v1.R'
source(paste(sourcedir, source3, sep=""))

# R functions for interacting with r8s (Sanderson 200x)
# Load with:
source3 = 'r8s_functions_v1.R'
source(paste(sourcedir, source3, sep=""))

library(phangorn)  # helps with "midpoint" function
#library(picante)  # for "Kcalc" and "phylosignal", i.e. calculation of the kappa statistic for continuous parameters
library(phylobase)
library(BioGeoBEARS)
sourceall("/drives/Dropbox/_njm/__packages/BioGeoBEARS_setup/")

wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/09_regressions/"
setwd(wd)


starbeast_trfn = "Gehyra_106loci_divideConquer_combinedTree_mcc_newDates_newNames.newick"
starbeast_tr = read.tree(file=starbeast_trfn)
plot(starbeast_tr)

trfns = c("Beast2_44species_calib2_treeLog.mcc_asDisplayed_newNames.newick", "r8s_547loci_Langley-Fitch_strict_clock_tree_newNames_noOutgroups.newick")

tr_names = c("concat_Beast2_44species", "concat_r8s_44species")


starbeast_trtable = prt(starbeast_tr, printflag=FALSE, get_tipnames=TRUE)
tail(starbeast_trtable)
internal_nodenums = (length(starbeast_tr$tip.label)+1):(length(starbeast_tr$tip.label)+starbeast_tr$Nnode)
starBeast2_tipnames = starbeast_trtable$tipnames[internal_nodenums]
ages_table = matrix(data=NA, nrow=length(internal_nodenums), ncol=(length(trfns)+1))
ages_table[,1] = starbeast_trtable$time_bp[internal_nodenums]

# Reduce the tiplabels in concatenated trees down to the species names
trs_list = NULL
trs_list2 = NULL
trs_list2[[1]] = starbeast_tr
list_of_node_id_taxa_for_each_tree = NULL
list_of_node_id_taxa_for_each_tree2 = NULL
list_of_node_id_taxa_for_each_tree2[[1]] = starBeast2_tipnames
for (i in 1:length(trfns))
	{
	trfn = trfns[i]
	tr = read.tree(trfn)
	tiplabels = tr$tip.label
	#plot(tr)
	
	# Take just the first word, before the "_"
	for (j in 1:length(tiplabels))
		{
		words = strsplit(tiplabels[j], split="_")[[1]]
		tiplabels[j] = words[1]
		}
	tr$tip.label = tiplabels
	trs_list[[i]] = tr
	trs_list2[[i+1]] = tr
	# 
	tmp_trtable = prt(tr, printflag=FALSE, get_tipnames=TRUE)
	list_of_taxa = tmp_trtable$tipnames
	tmp_internal_nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	# Reduce to unique
	for (k in 1:length(list_of_taxa))
		{
		words = strsplit(list_of_taxa[k], split=",")[[1]]
		newwords = unique(words)
		newtxt = paste0(newwords, collapse=",")
		list_of_taxa[k] = newtxt
		}
	list_of_node_id_taxa_for_each_tree[[i]] = list_of_taxa
	list_of_node_id_taxa_for_each_tree2[[i+1]] = list_of_taxa[tmp_internal_nodenums]
	} # END for (i in 1:length(trfns))

# Make it a multiPhylo
class(trs_list) = "multiPhylo"
class(trs_list2) = "multiPhylo"

list_of_node_id_taxa_for_each_tree

# OK, now, look for matches
for (i in 1:length(trfns))
	{
	trfn = trfns[i]
	tr = read.tree(trfn)
	tmp_trtable = prt(tr, printflag=FALSE, get_tipnames=TRUE)
	tmp_internal_nodenums = (length(tr$tip.label)+1):(length(tr$tip.label)+tr$Nnode)
	tmp_node_id_taxa = list_of_node_id_taxa_for_each_tree[[i]] 
	matches_to_starBeast2_trtable = match(x=starBeast2_tipnames, table=tmp_node_id_taxa)
	ages_table[,i+1] = tmp_trtable$time_bp[matches_to_starBeast2_trtable]
	} # END for (i in 1:length(trfns))

ages_table = as.data.frame(ages_table, stringsAsFactors=FALSE)
ages_table = dfnums_to_numeric(ages_table)
names(ages_table) = c("starBeast2", tr_names)
row.names(ages_table) = starBeast2_tipnames

head(ages_table)
tail(ages_table)

out_table_fn = "ages_StarBeast2_vs_concat.txt"
write.table(x=ages_table, file=out_table_fn, quote=FALSE, sep="\t", row.names=TRUE, col.names=TRUE)

#######################################################
# Regression plots
#######################################################
pdffn = "regressions_StarBeast2_vs_concat.pdf"
pdf(file=pdffn, width=6, height=6)


tr_names2 = c("StarBeast2", tr_names)
for (i in (1:length(tr_names2)))
	{
	x=ages_table[,1]
	y=ages_table[,i]
	ylabel = paste0(tr_names2[i], " node age")
	output = linear_regression_plot(x, y, xlabel="StarBeast2 node age", ylabel=ylabel, xlim=c(0,15), ylim=c(0,15), tmppch=1, intercept_in_legend=TRUE)
	
	#intercept = output$coefficients[1]
	
	titletxt = paste0("Mean node ages:\n", tr_names2[1], " vs. ", tr_names2[i])
	title(titletxt)
	} # END for (i in (2:(length(trfns)+1)))

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)


#######################################################
# Minimum Lineages-through-Time plots
#######################################################

# Correct the tips so they all come to exactly zero!!
methods_list = c("lowest", "lowest", "mean", "highest", "highest")

trs_list2[[1]] = level_tree_tips(trs_list2[[1]], method=methods_list[1], printflag=FALSE, fossils_older_than=0.6)
trs_list2[[2]] = level_tree_tips(trs_list2[[2]], method=methods_list[2], printflag=FALSE, fossils_older_than=0.6)

tmptr = level_tree_tips(trs_list2[[3]], method="mean", printflag=FALSE, fossils_older_than=0.6)
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero
ltt.plot(tmptr, ylim=c(0,90), tol=0)
trs_list2[[3]] = tmptr

# trs_list2[[4]] = level_tree_tips(trs_list2[[4]], method=methods_list[4], printflag=FALSE, fossils_older_than=0.6)
# trs_list2[[5]] = level_tree_tips(trs_list2[[5]], method=methods_list[5], printflag=FALSE, fossils_older_than=0.6)



pdffn = "Gehyra_106_loci_LTT_plots_v1.pdf"
pdf(file=pdffn, width=6, height=6)

for (i in 1:length(trs_list2))
	{
	tr = trs_list2[[i]]
	#tr = average_tr_tips(tr, fossils_older_than=0.6)
	#tr = level_tree_tips(tr, method=methods_list[i], printflag=FALSE, fossils_older_than=0.6)
	
	# Gamma-Statistic of Pybus and Harvey
	gammastat = gammaStat(phy=tr)
	
	ltt.plot(tr, ylim=c(0,90), tol=0)
	titletxt = paste0("(minimum) Lineages-through-time (LTT) plot for\n", tr_names2[i])
	title(titletxt)
	gamma_txt = paste0("Gamma = ",round(gammastat,3))
	legend(x="topleft", legend=gamma_txt, bty="n")
	}
dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)


pdffn = "Gehyra_106_loci_log-LTT_plots_v1.pdf"
pdf(file=pdffn, width=6, height=6)

for (i in 1:length(trs_list2))
	{
	tr = trs_list2[[i]]
	#tr = average_tr_tips(tr, fossils_older_than=0.6)
	#tr = level_tree_tips(tr, method=methods_list[i], printflag=FALSE, fossils_older_than=0.6)
	
	# Gamma-Statistic of Pybus and Harvey
	gammastat = gammaStat(phy=tr)
	

	ltt.plot(tr, tol=0, log="y")
	titletxt = paste0("(minimum) Log-lineages-through-time (log-LTT) plot for\n", tr_names2[i])
	title(titletxt)
	gamma_txt = paste0("Gamma = ",round(gammastat,3))
	legend(x="topleft", legend=gamma_txt, bty="n")
	}

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)





#######################################################
# Gamma stats and LTTs over a sample of trees
#######################################################





#######################################################
# Topological differences
#######################################################
outgroups = c("CYsp", "dubia")
trs_list3 = trs_list2[c(1,2,4)]
distmat = matrix(data="", nrow=length(trs_list3), ncol=length(trs_list3))
for (i in 1:length(trs_list3))
	{
	tr = trs_list3[[i]]
	tr2 = drop.tip(tr, tip=outgroups)
	
	for (j in 1:length(trs_list3))
		{
		tr_j = trs_list3[[j]]
		tr2_j = drop.tip(tr_j, tip=outgroups)
		distmat[i,j] = RF.dist(tree1=tr2, tree2=tr2_j, rooted=TRUE)
		}
	}


distmat = as.data.frame(distmat, stringsAsFactors=FALSE)
names(distmat) = tr_names2[c(1,2,4)]
row.names(distmat) = tr_names2[c(1,2,4)]




list_of_node_id_taxa_for_each_tree2

distmat2 = matrix(data="", nrow=length(list_of_node_id_taxa_for_each_tree2), ncol=length(list_of_node_id_taxa_for_each_tree2))
for (i in 1:length(list_of_node_id_taxa_for_each_tree2))
	{
	list1 = list_of_node_id_taxa_for_each_tree2[[i]]
	
	for (j in 1:length(list_of_node_id_taxa_for_each_tree2))
		{
		list2 = list_of_node_id_taxa_for_each_tree2[[j]]
		matches_TF = list1 %in% list2
		distmat2[i,j] = sum(matches_TF)
		}
	}

distmat2 = as.data.frame(distmat2, stringsAsFactors=FALSE)
names(distmat2) = tr_names2
row.names(distmat2) = tr_names2

distmat2





