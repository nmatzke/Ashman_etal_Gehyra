

library(ape)
library(BioGeoBEARS)


wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/09_regressions/"
setwd(wd)

trs_fns = c("Gehyra_106loci_divideConquer.nexus", "Beast2_44species_calib2_treeLog.txt")


MCC_trs_fns = c("Gehyra_106loci_divideConquer_combinedTree_mcc_newDates_newNames.newick",
"Beast2_44species_calib2_treeLog.mcc_asDisplayed_newNames.newick", "r8s_547loci_Langley-Fitch_strict_clock_tree_newNames_noOutgroups.newick")

tr_names = c("starBeast2_44species", "concat_Beast2_44species", "concat_r8s_44species")

outgroups = c("dubia", "CYsp", "dubia_RPCAP03_Geck1_h0", "CYsp_RPCAP03_ABTC79193_h0")

pdffn = "LTTs_gammas_100trees.pdf"
pdf(file=pdffn, width=12, height=12)
par(mfrow=c(2,2))

# For each tree:
# 1. Plot MCC tree
# 2. Plot mLTT plots
# 3. Plot histogram of gamma stats
# 4. Also get LTT plot coordinates
num_lineages_array_list = list()
mean_LTT_lines = list()
median_LTT_lines = list()
histograms_list = list()
gamma_stat_vals_list = list()
for (i in 1:length(trs_fns))
	{
	trs_fn = trs_fns[i]
	if (i==2)
		{
		runslow = FALSE
		if (runslow)
			{
			trs = read.nexus(trs_fn)
			halfnum = round(length(trs)/2, 0)
			nums = halfnum:length(trs)
			nums_to_keep = sample(x=nums, size=100, replace=FALSE)
			trs = trs[nums_to_keep]
			save(trs, file="trs.nexus")
			} else {
			load(file="trs.nexus")
			}
		} else {
		trs = read.nexus(trs_fn)
		halfnum = round(length(trs)/2, 0)
		nums = halfnum:length(trs)
		nums_to_keep = sample(x=nums, size=100, replace=FALSE)
		trs = trs[nums_to_keep]
		}
	
	
	MCC_trfn = MCC_trs_fns[i]
	MCC_tr = read.tree(MCC_trfn)
	MCC_tr = drop.tip(MCC_tr, tip=outgroups)
	
	MCC_gamma = round(gammaStat(MCC_tr), 3)
	
	gamma_stat_vals = rep(NA, times=length(trs))
	for (j in 1:length(trs))
		{
		gamma_stat_vals[j] = gammaStat(trs[[j]])
		} # END for (j in 1:length(trs))
	gamma_stat_vals_list[[i]] = gamma_stat_vals
	
	lower95 = round(quantile(x=gamma_stat_vals, probs=c(0.025)), 2)
	upper95 = round(quantile(x=gamma_stat_vals, probs=c(0.975)), 2)
	mean50 = round(mean(gamma_stat_vals), 2)
	median50 = round(quantile(x=gamma_stat_vals, probs=c(0.50)), 2)
	
	txt = paste0("MCC gamma = ", MCC_gamma, "\n",
	"mean gamma = ", mean50, "\n",
	"gamma 95% HPD = (", lower95, ", ", upper95, ")")
	
	# Plot phylogeny
	if (i == 2)
		{
		#plot(1,1, pch=".", xlim=c(-15,2), ylim=c(0,length(MCC_tr$tip.label)))
		plot(ladderize(MCC_tr, right=FALSE))
		axisPhylo()
		title(tr_names[i])
		} else {
		plot(ladderize(MCC_tr, right=FALSE))
		axisPhylo()
		title(tr_names[i])		
		}
	
	
	# Plot histogram
	histograms_list[[i]] = hist(gamma_stat_vals, breaks=50, main="distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0))
	
	abline(v=MCC_gamma, lwd=4, col="blue")

	abline(v=lower95, lwd=1, col="blue", lty="dashed")
	abline(v=upper95, lwd=1, col="blue", lty="dashed")
	abline(v=mean50, lwd=4, col="blue", lty="dashed")
	abline(v=median50, lwd=2, col="blue", lty="dashed")
	
	legend(x="topright", legend=txt, box.col="white", bty="o", bg="white", cex=0.85)

	# Plot LTT
	mltt.plot(phy=trs, dcol=FALSE, dlty=FALSE, legend=FALSE,
          xlab = "Time", ylab = "N", log = "", backward = TRUE,
          tol = 1e-6)
    title("(minimum) Lineages-through-time (LTT) plot")
	
	if (i == 2)
		{
		numnodes = length(trs[[1]]$tip.label) + length(trs[[1]]$tip.label) - 1
		num_lineages_array = array(data=NA, dim=c(numnodes, 2, length(trs)))
		} else {
		numnodes = length(trs[[1]]$tip.label)
		num_lineages_array = array(data=NA, dim=c(numnodes, 2, length(trs)))
		
		}
	for (j in 1:length(trs))
		{
		x = ltt.plot.coords(phy=trs[[j]], backward=TRUE)
		num_lineages_array[,,j] = x
		}
	num_lineages_array_list[[i]] = num_lineages_array
	mean_LTT_lines[[i]] = apply(X=num_lineages_array_list[[i]], MARGIN=c(1,2), FUN=mean)
	median_LTT_lines[[i]] = apply(X=num_lineages_array_list[[i]], MARGIN=c(1,2), FUN=median)
	
	# Plot log-LTT
	mltt.plot(phy=trs, dcol=FALSE, dlty=FALSE, legend=FALSE,
          xlab = "Time", ylab = "N (log scale)", log = "y", backward = TRUE,
          tol = 1e-6)
    title("(minimum) Log-lineages-through-time (log-LTT) plot")
	} # END for (i in 1:length(trs_fns))


dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)









pdffn = "mean_LTTs_v1.pdf"
pdf(file=pdffn, width=11, height=5.5)


#######################################################
# Plot mean LTT lines on top of each other, and 
# histograms on top of each other
#######################################################

# Mean # lineages across 100 trees
par(mfrow=c(1,2))
# StarBeast2
x = mean_LTT_lines[[1]][,1]
y = mean_LTT_lines[[1]][,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", xlim=c(-15,0))
title("(minimum) Lineages-through-time (LTT) plot\n(100 posterior LTTs: mean ages of each diversity level)")
lines(x,y, col="red")

# Concatenated Beast2
x = mean_LTT_lines[[2]][,1]
y = mean_LTT_lines[[2]][,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))




########################################
# Use MCC trees
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", xlim=c(-15,0))
title("(minimum) Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))



#######################################################
# LOG VERSION - Plot mean LTT lines on top of each other, and 
# histograms on top of each other
#######################################################

# Mean # lineages across 100 trees
par(mfrow=c(1,2))
# StarBeast2
x = mean_LTT_lines[[1]][,1]
y = mean_LTT_lines[[1]][,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(100 posterior LTTs: mean ages of each diversity level)")
lines(x,y, col="red")

# Concatenated Beast2
x = mean_LTT_lines[[2]][,1]
y = mean_LTT_lines[[2]][,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))



########################################
# Use MCC trees
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))


dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)












pdffn = "median_LTTs_v1.pdf"
pdf(file=pdffn, width=11, height=5.5)


#######################################################
# Plot median LTT lines on top of each other, and 
# histograms on top of each other
#######################################################

# median # lineages across 100 trees
par(mfrow=c(1,2))
# StarBeast2
x = median_LTT_lines[[1]][,1]
y = median_LTT_lines[[1]][,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", xlim=c(-15,0))
title("(minimum) Lineages-through-time (LTT) plot\n(100 posterior LTTs: median ages of each diversity level)")
lines(x,y, col="red")

# Concatenated Beast2
x = median_LTT_lines[[2]][,1]
y = median_LTT_lines[[2]][,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))




########################################
# Use MCC trees
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", xlim=c(-15,0))
title("(minimum) Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))



#######################################################
# LOG VERSION - Plot median LTT lines on top of each other, and 
# histograms on top of each other
#######################################################

# Median # lineages across 100 trees
par(mfrow=c(1,2))
# StarBeast2
x = median_LTT_lines[[1]][,1]
y = median_LTT_lines[[1]][,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(100 posterior LTTs: median ages of each diversity level)")
lines(x,y, col="red")

# Concatenated Beast2
x = median_LTT_lines[[2]][,1]
y = median_LTT_lines[[2]][,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))



########################################
# Use MCC trees
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2"), col=c("red", "blue"), lty="solid")

# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))


dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)




pdffn = "LTTs_star_concat_r8s_v1.pdf"
pdf(file=pdffn, width=11, height=5.5)


########################################
# Use MCC trees, AND r8s tree
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

r8s_trfn = MCC_trs_fns[3]
r8s_tr3 = read.tree(r8s_trfn)


par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")

# RAxML + r8s tree
# Make all the tips come to 0
tmptr = r8s_tr3
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="green3")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2", "RAxML + r8s"), col=c("red", "blue", "green3"), lty="solid")


gamma1 = round(gammaStat(MCC_tr1), 2)
gamma2 = round(gammaStat(MCC_tr2), 2)
gamma3 = round(gammaStat(r8s_tr3), 2)

tmptxt = paste0("StarBeast2 MCC Gamma:", gamma1, "\nConcat. Beast2 Gamma: ", gamma2, "\nRAxML + r8s Gamma: ", gamma3)
tmptxt1 = paste0("StarBeast2 MCC Gamma:", gamma1)
tmptxt2 = paste0("Concat. Beast2 Gamma: ", gamma2)
tmptxt3 = paste0("RAxML + r8s Gamma: ", gamma3)


# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))
text(x=-4, y=16.5, labels=tmptxt1, adj=c(0), col="red")
text(x=-4, y=15.5, labels=tmptxt2, adj=c(0), col="blue")
text(x=-4, y=14.5, labels=tmptxt3, adj=c(0), col="green3")

segments(x1=gamma1, x0=gamma1, y0=-0.5, y1=13.5, lwd=4, col="red1", lty="longdash")
segments(x1=gamma2, x0=gamma2, y0=-0.5, y1=13.5, lwd=4, col="lightblue", lty="longdash")
segments(x1=gamma3, x0=gamma3, y0=-0.5, y1=13.5, lwd=4, col="green3", lty="longdash")

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)







pdffn = "LTTs_star_concat_r8s_v1b.pdf"
pdf(file=pdffn, width=11, height=5.5)


########################################
# Use MCC trees, AND r8s tree
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

r8s_trfn = MCC_trs_fns[3]
r8s_tr3 = read.tree(r8s_trfn)


par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")

# RAxML + r8s tree
# Make all the tips come to 0
tmptr = r8s_tr3
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="green3")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2", "RAxML + r8s"), col=c("red", "blue", "green3"), lty="solid")


gamma1 = round(gammaStat(MCC_tr1), 2)
gamma2 = round(gammaStat(MCC_tr2), 2)
gamma3 = round(gammaStat(r8s_tr3), 2)

tmptxt = paste0("StarBeast2 MCC Gamma:", gamma1, "\nConcat. Beast2 Gamma: ", gamma2, "\nRAxML + r8s Gamma: ", gamma3)
tmptxt1 = paste0("StarBeast2 mean Gamma:", mean50_1)
tmptxt2 = paste0("Beast2 mean Gamma: ", mean50_2)
tmptxt3 = paste0("RAxML + r8s Gamma: ", gamma3)


# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))
text(x=-4, y=16.5, labels=tmptxt1, adj=c(0), col="red")
text(x=-4, y=15.5, labels=tmptxt2, adj=c(0), col="blue")
text(x=-4, y=14.5, labels=tmptxt3, adj=c(0), col="green3")

#segments(x1=gamma1, x0=gamma1, y0=-0.5, y1=13.5, lwd=4, col="red1", lty="longdash")
#segments(x1=gamma2, x0=gamma2, y0=-0.5, y1=13.5, lwd=4, col="lightblue", lty="longdash")
segments(x1=gamma3, x0=gamma3, y0=-0.5, y1=13.5, lwd=4, col="green3", lty="longdash")

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)






pdffn = "LTTs_star_concat_r8s_v2.pdf"
pdf(file=pdffn, width=11, height=5.5)


########################################
# Use MCC trees, AND r8s tree
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

r8s_trfn = MCC_trs_fns[3]
r8s_tr3 = read.tree(r8s_trfn)


par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")

# RAxML + r8s tree
# Make all the tips come to 0
tmptr = r8s_tr3
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="green3")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2", "RAxML + r8s"), col=c("red", "blue", "green3"), lty="solid")


gamma1 = round(gammaStat(MCC_tr1), 2)
gamma2 = round(gammaStat(MCC_tr2), 2)
gamma3 = round(gammaStat(r8s_tr3), 2)

tmptxt1 = paste0("StarBeast2 MCC Gamma:", gamma1)
tmptxt2 = paste0("Concat. Beast2 Gamma: ", gamma2)
tmptxt3 = paste0("RAxML + r8s Gamma: ", gamma3)


# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))
text(x=-4, y=16.5, labels=tmptxt1, adj=c(0), col="red")
text(x=-4, y=15.5, labels=tmptxt2, adj=c(0), col="blue")
text(x=-4, y=14.5, labels=tmptxt3, adj=c(0), col="green3")

#segments(x1=gamma1, x0=gamma1, y0=-0.5, y1=13.5, lwd=4, col="red1", lty="longdash")
#segments(x1=gamma2, x0=gamma2, y0=-0.5, y1=13.5, lwd=4, col="lightblue", lty="longdash")
#segments(x1=gamma3, x0=gamma3, y0=-0.5, y1=13.5, lwd=4, col="green3", lty="longdash")

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)




pdffn = "LTTs_star_concat_r8s_v3.pdf"
pdf(file=pdffn, width=11, height=5.5)


########################################
# Use MCC trees, AND r8s tree
########################################
MCC_trfn = MCC_trs_fns[1]
MCC_tr = read.tree(MCC_trfn)
MCC_tr1 = drop.tip(MCC_tr, tip=outgroups)

MCC_trfn = MCC_trs_fns[2]
MCC_tr = read.tree(MCC_trfn)
MCC_tr2 = drop.tip(MCC_tr, tip=outgroups)

r8s_trfn = MCC_trs_fns[3]
r8s_tr3 = read.tree(r8s_trfn)


par(mfrow=c(1,2))

# StarBeast2
# Make all the tips come to 0
tmptr = MCC_tr1
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

# StarBeast2
x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
plot(x, y, pch=".", col="white", xlab="millions of years", ylab="number of lineages", log="y", xlim=c(-15,0))
title("(minimum) log-Lineages-through-time (LTT) plot\n(from Maximum Clade Credibility (MCC) trees)")
lines(x,y, col="red")

# Concatenated Beast2
# Make all the tips come to 0
tmptr = MCC_tr2
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="blue")

# RAxML + r8s tree
# Make all the tips come to 0
tmptr = r8s_tr3
tmptable = prt(tmptr, printflag=FALSE)
tipnums = 1:length(tmptr$tip.label)
diff_from_zero = tmptable$time_bp[tipnums]
tmptr$edge.length[tmptable$parent_br[tipnums]] = tmptr$edge.length[tmptable$parent_br[tipnums]] + diff_from_zero

x = ltt.plot.coords(phy=tmptr, backward=TRUE)[,1]
y = ltt.plot.coords(phy=tmptr, backward=TRUE)[,2]
#plot(x, y, pch=".", col="white")
lines(x,y, col="green3")
legend(x="topleft", legend=c("StarBeast2", "Concatenated Beast2", "RAxML + r8s"), col=c("red", "blue", "green3"), lty="solid")


gamma1 = round(gammaStat(MCC_tr1), 2)
gamma2 = round(gammaStat(MCC_tr2), 2)
gamma3 = round(gammaStat(r8s_tr3), 2)

tmptxt = paste0("StarBeast2 MCC Gamma:", gamma1, "\nConcat. Beast2 Gamma: ", gamma2, "\nRAxML + r8s Gamma: ", gamma3)


# Histogram Colored (blue and red)
hist(gamma_stat_vals_list[[1]], col=rgb(1,0,0,0.5), breaks=20, main="Distribution of gamma statistics\nfrom 100 posterior trees", xlim=c(-7,0), ylim=c(0,20), xlab="gamma statistic")
hist(gamma_stat_vals_list[[2]], col=rgb(0,0,1,0.5), breaks=20, add=T)
legend(x="topright", legend=c("StarBeast2", "Concatenated Beast2"), fill=c("red", "blue"))
#text(x=-4, y=15.5, labels=tmptxt, adj=c(0))

#segments(x1=gamma1, x0=gamma1, y0=-0.5, y1=13.5, lwd=4, col="red1", lty="longdash")
#segments(x1=gamma2, x0=gamma2, y0=-0.5, y1=13.5, lwd=4, col="lightblue", lty="longdash")
#segments(x1=gamma3, x0=gamma3, y0=-0.5, y1=13.5, lwd=4, col="green3", lty="longdash")

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)





#######################################################
# Statistical test for a difference in means
#######################################################

# Comparison of StarBeast2 vs. Beast2 gamma statistics
t.test(x=gamma_stat_vals_list[[1]], y=gamma_stat_vals_list[[2]], alternative="two.sided", mu=0, paired=FALSE)

# 	Welch Two Sample t-test
# 
# data:  gamma_stat_vals_list[[1]] and gamma_stat_vals_list[[2]]
# t = 34.827, df = 172.22, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  2.228380 2.496141
# sample estimates:
# mean of x mean of y 
# -1.766700 -4.128961 
# 
# # Comparison of Beast2 gamma statistics vs. RAxML/r8s gamma statistic
t.test(x=gamma_stat_vals_list[[2]], alternative="two.sided", mu=-5.31, paired=FALSE)

# 	One Sample t-test
# 
# 	One Sample t-test
# 
# data:  gamma_stat_vals_list[[2]]
# t = 31.448, df = 99, p-value < 2.2e-16
# alternative hypothesis: true mean is not equal to -5.31
# 95 percent confidence interval:
#  -4.203478 -4.054443
# sample estimates:
# mean of x 
# -4.128961 



