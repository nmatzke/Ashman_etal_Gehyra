
#######################################################
#######################################################
# Divide-and-conquer analysis: merge subtree samples into skeleton tree samples
#######################################################
#######################################################



#######################################################
# Setup
#######################################################
library(BioGeoBEARS)
sourceall("/GDrive/__github/BEASTmasteR/R/")


wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/"
setwd(wd)



#######################################################
# Skeleton tree setup
#######################################################
skel_dir = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1cip/2016-10-27b_date2/"
#skel_trfn = "treeLog.txt"
skel_trfn = "treeLog_wEnd.txt"

skel_trfns = slashslash(paste0(skel_dir, skel_trfn))

# Set the burnin (number of trees)
skel_burnin = 10000

skel_trs = read.nexus(skel_trfns)

trnums = 1:length(skel_trs)
trnums = trnums[trnums > skel_burnin]
length(trnums)

# Subsample treenums
numtrees_to_output = 1000

if (length(trnums) < numtrees_to_output)
	{
	numtrees_to_output = length(trnums)
	} else {
	# Sub-sample tree numbers
	trnums = sample(x=trnums, size=numtrees_to_output, replace=FALSE)
	}
length(trnums)



#######################################################
# Subtree setup
#######################################################
# Subtree (species subtree) filenames:
subtree_dirs = c("/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_subgroup1_var+punct/",
"/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_subgroup2_polka/",
"/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_subgroup3_plo/",
"/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_subgroup4_nanaGrp_v2/")

subtree_fns = c("treeLog_wEnd.txt", "treeLog.txt", "treeLog.txt", "treeLog_wEnd.txt")
subtree_fns = slashslash(paste0(subtree_dirs, subtree_fns))

# Outgroups to remove
nn = 0
outgroups_to_remove = list()
outgroups_to_remove[[(nn=nn+1)]] = c("cundalensis")
outgroups_to_remove[[(nn=nn+1)]] = c("cundalensis")
outgroups_to_remove[[(nn=nn+1)]] = c("moritzi")
outgroups_to_remove[[(nn=nn+1)]] = c("ornata", "lazelli")


# List of tree objects
cat("\nReading in subtrees for ", length(subtree_fns), " NEXUS files...", sep="")
list_of_multiPhylos = list()
for (i in 1:length(subtree_fns))
	{
	cat(i, " ", sep="")
	tmp_trs = read.nexus(subtree_fns[i])
	cat("\nNumber of trees in ", subtree_fns[i], " = ", length(tmp_trs))
	list_of_multiPhylos[[i]] = tmp_trs
	}
cat("\n...done.")
#list_of_multiPhylos

burnins = c(50000, 50000, 50000, 30000)


#######################################################
# List of subtree mappings to skeleton tree
#######################################################
useTF = c(TRUE, TRUE, TRUE, TRUE)

nn = 0
skeltree_specifiers_list = list()
skeltree_specifiers_list[[(nn=nn+1)]] = c("variegata", "versicolor5", "punctata", "burrupensis")
skeltree_specifiers_list[[(nn=nn+1)]] = c("polka4", "fenestrula")
skeltree_specifiers_list[[(nn=nn+1)]] = c("ornata", "pulingka")
skeltree_specifiers_list[[(nn=nn+1)]] = c("nana5", "gilulu")
numtips_in_skeleton_tree_subclade = sapply(X=skeltree_specifiers_list, FUN=length)
sort_unique_skeltree_specifiers_list = sort(unique(unlist(skeltree_specifiers_list)))

cat("\nMerging subtrees onto ", length(trnums), " dated skeleton trees...\n", sep="")
cat("Key: 'y'=all subtree clades found as monophyletic; 'n'=not all found, skipping this skeleton tree.\n\n")

# Loop through the selected skeleton trees
new_trs = list()
for (j in 1:length(trnums))
	{
	break_test = FALSE
	cat(j, sep="")
	tmptr = skel_trs[[trnums[j]]]

	# Double-check that the tip specifiers are indeed in the subtree
	TF = sort_unique_skeltree_specifiers_list %in% tmptr$tip.label
	if (sum(TF) != length(sort_unique_skeltree_specifiers_list))
		{
		stoptxt = paste0("STOP ERROR at trnum j=", j, ": some/all of the specifiers in skeltree_specifiers_list were not in the skeleton tree.")
		cat("\n\n")
		cat(stoptxt)
		cat("\n\n")
		stop(stoptxt)
		}

	
	# For a particular skeleton tree, paste in randomly-sampled 
	# subtrees when the clade exists
	for (i in 1:length(subtree_dirs))
		{
		if (useTF[i] == FALSE)
			{
			next()
			}

		# Find the clade in the skeleton tree
		# find the nodenum of the mrca
		nodenum = getMRCA(phy=tmptr, tip=skeltree_specifiers_list[[i]])
		skeleton_subtree = extract.clade(phy=tmptr, node=nodenum)
		ntips = length(skeleton_subtree$tip.label)
		
		# If the clade isn't actually monophyletic in the sampled
		# skeleton tree, don't try to add it; skip this skeleton tree
		if (ntips != numtips_in_skeleton_tree_subclade[i])
			{
			break_test = TRUE
			cat("n ", sep="")
			break()
			}
		
		
		# Randomly sample a subtree
		# (and exclude burnin trees)
		subtree_nums = 1:length(list_of_multiPhylos[[i]])
		subtree_nums = subtree_nums[subtree_nums > burnins[i]]
		subtree_num = sample(x=subtree_nums, size=1, replace=TRUE)
		subtree = list_of_multiPhylos[[i]][[subtree_num]]
		
		# Remove any outgroups
		subtree_tmp = drop.tip(phy=subtree, tip=outgroups_to_remove[[i]])
		subtree = read.tree(file="", text=write.tree(phy=subtree_tmp, file=""))
		
		# Double-check that the tip specifiers are indeed in the subtree
		TF = skeltree_specifiers_list[[i]] %in% subtree$tip.label
		if (sum(TF) != length(skeltree_specifiers_list[[i]]))
			{
			stoptxt = paste0("STOP ERROR at trnum j=", j, " subtree_dirs i=", i, ": some/all of the specifiers in skeltree_specifiers_list[[", i, "]] were not in the subtree from subtree_dirs[", i, "]: '", subtree_dirs[i], "'.")
			cat("\n\n")
			cat(stoptxt)
			cat("\n\n")
			stop(stoptxt)
			}
		
		# Temporary save
		tmptr_orig = tmptr
		
		
		# Remove the old tips from the skeleton tree
		# (replaced with tip "NA")
		tmptr2 = drop.tip(phy=tmptr, tip=skeltree_specifiers_list[[i]], trim.internal=FALSE)
		tmptr = read.tree(file="", text=write.tree(phy=tmptr2, file=""))
		
		# Paste the subtree in at NA
		TF = tmptr$tip.label == "NA"
		
		
		# For some reason, drop.tip on a clade of 4 species can produce
		# two NA tips. The function drop_tips_NA() fixes that issue.
		if (sum(TF) > 1)
			{
			plot(tmptr)
			tmptr = drop_tips_NA(tmptr=tmptr, copied_tiplabel_to_drop="NA")
			} # END if (sum(TF) > 1)

		# If for some reason you STILL have more than one NA, you have 
		# bigger problems. So, hard stop.
		TF = tmptr$tip.label == "NA"
		if (sum(TF) > 2)
			{
			stoptxt = paste0("At trnum j=", j, " subtree_dirs i=", i, " you had more than 2 NAs after the skeltree_specifiers_list[[", i, "]] were dropped.")
			cat("\n\n")
			cat(stoptxt)
			cat("\n\n")
			stop(stoptxt)
			} # END if (sum(TF) > 2)


		# Get the age of the NA tip
		tr_table = prt(tmptr, printflag=FALSE)
		tip_nums = 1:length(tmptr$tip.label)
		tip_ages = tr_table$time_bp[tip_nums]
		TF = tr_table$label[tip_nums] == "NA"
		node_age = tip_ages[TF]

		# Rescale the subtree to the heights specified by the skeleton tree
		subtr_height = max(branching.times(subtree))
		subtree$edge.length = subtree$edge.length * node_age / subtr_height


		# Insert the subtree at the last NA
		tipnode_to_insert_at = (1:length(tmptr$tip.label))[TF]
		tmptr_binded = bind.tree(x=tmptr, y=subtree, where=tipnode_to_insert_at, position=0, interactive=FALSE)
		tmptr = tmptr_binded
		
		# Check if all the tips come up to 0
		cutoff = 0.1
		tr_table = prt(tmptr, printflag=FALSE)
		tip_ages = tr_table$time_bp[1:length(tmptr$tip.label)]
		if (any(tip_ages > cutoff))
			{
			stoptxt = paste0("STOP ERROR in function: merged tree has tips of greatly different ages. Error occured at trnum j=", j, ", subtree_dirs i=", i, "")
			cat("\n\n")
			cat(stoptxt)
			cat("\n\n")
			stop(stoptxt)
			} # END if (any(tip_ages > cutoff))
		
		# Check for duplicate tips
		if (length(tmptr$tip.label) != length(unique(tmptr$tip.label)))
			{
			stoptxt = paste0("Error in function: the merged tree has duplicate tiplabels.")
		
			cat("\n\n")
			cat(stoptxt)
			cat("\n\n")
			cat("Sorted tip labels:")
			cat("\n\n")
			print(sort(tmptr$tip.label))
			cat("\n\nSorted, unique tip labels:")
			cat("\n\n")
			print(sort(unique(tmptr$tip.label)))
			cat("\n\n")
			cat("Counts:\n\n")
			print(table(tmptr$tip.label))
			stop(stoptxt)
			} # END if (length(tmptr$tip.label) != length(unique(tmptr$tip.label)))
		
		# Re-write the tree, go to the next loop
		tmptr = read.tree(file="", text=write.tree(phy=tmptr, file=""))
		# Temporary save
		most_recent_skeltree_w_subclade_added = tmptr
		} # END for (i in 1:length(subtree_dirs))

	# Non-monophyly observed, so skip this skeleton tree
	if (break_test == TRUE)
		{
		next()
		}
	
	# Check the tree for duplicate tips
	tmp_labels = tmptr$tip.label
	
	if (length(tmp_labels) != length(unique(tmp_labels)))
		{
		stoptxt = paste0("Error in function: the merged tree has duplicate tiplabels.")
		
		cat("\n\n")
		cat(stoptxt)
		cat("\n\n")
		cat("Sorted tip labels:")
		cat("\n\n")
		print(sort(tmp_labels))
		cat("\n\nSorted, unique tip labels:")
		cat("\n\n")
		print(sort(unique(tmp_labels)))
		cat("\n\n")
		cat("Counts:\n\n")
		print(table(tmp_labels))		
		stop(stoptxt)
		} # END if (length(tmp_labels) != length(unique(tmp_labels)))
	
	# Save the tree in the new trees list
	new_trs = c(new_trs, list(tmptr))
	cat("y ", sep="")
	} # END for (j in 1:length(trnums))
cat("\n...done.")

numtips = sapply(X=new_trs, FUN=function(x){length(x$tip.label)})
TF = numtips == max(numtips)
new_trs2 = new_trs[TF]
length(new_trs2) # 645 trees matched all clades

new_trs3 = new_trs2
class(new_trs3) = "multiPhylo"
new_trs3
# 645 phylogenetic trees

new_trs3[[1]]
outfn = "merged_trees_v1.nexus"
write.nexus(new_trs3, file=outfn, translate=TRUE)

