library(XLConnect)
library(ape)
library(BioGeoBEARS)
source('/drives/GDrive/__github/BEASTmasteR/R/tree_utils_v1.R', chdir = TRUE)

# Working directory
wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/"
setwd(wd)

# Geog file
orig_geog_fn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/habitat.txt"

# Tip ranges
tipranges = getranges_from_LagrangePHYLIP(lgdata_fn=orig_geog_fn)
tipranges
areanames = colnames(tipranges@df)
areanames

# New Geog file
new_geog_fn = gsub(pattern=".txt", replacement="_newNames.txt", x=orig_geog_fn)





#######################################################
# Names in Excel file
#######################################################
# Excel workbook with old and new names
#xls_fn = "Ashman_etal_NEW_NAMES.xlsx"
xls_fn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/_08_BioGeoBEARS/BioGeoBEARS_coding_varpunc_biome_region_habitat_v3.xlsx"

xls = readWorksheetFromFile(file=xls_fn, sheet=1, startRow=1, endRow=43, startCol=1, endCol=10, header=TRUE)
names(xls)

old_names = xls$Publishable.names
new_names = xls$Names_for_BGB

#outfn = change_tipnames_in_treefile(file=orig_nex_fn, old_names, new_names, outfn=NULL)
tmp_names = row.names(tipranges@df)
tmp_names_revised = tmp_names
for (i in 1:nrow(tipranges@df))
	{
	tmp_name = tmp_names[i]
	name_num = which(old_names == tmp_name)
	tmp_names_revised[i] = new_names[name_num]
	} # END for (i in 1:nrow(tipranges@df))

cbind(tmp_names, tmp_names_revised)

# Put in the new names
row.names(tipranges@df) = tmp_names_revised

# Write out the file
save_tipranges_to_LagrangePHYLIP(tipranges_object=tipranges, lgdata_fn=new_geog_fn, areanames=areanames)

