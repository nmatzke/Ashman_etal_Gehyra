library(XLConnect)
library(ape)
library(BioGeoBEARS)
source('/drives/GDrive/__github/BEASTmasteR/R/tree_utils_v1.R', chdir = TRUE)

# Working directory
wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/"
setwd(wd)

# Tree file
orig_trfn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/Langley-Fitch_strict_clock_tree.newick"

# Tree file
tr = read.tree(orig_trfn)

# New Geog file
new_trfn = gsub(pattern=".newick", replacement="_newNames.newick", x=orig_trfn)





#######################################################
# Names in Excel file
#######################################################
# Excel workbook with old and new names
#xls_fn = "Ashman_etal_NEW_NAMES.xlsx"
xls_fn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/_08_BioGeoBEARS/BioGeoBEARS_coding_varpunc_biome_region_habitat_v3.xlsx"

xls = readWorksheetFromFile(file=xls_fn, sheet=1, startRow=1, endRow=43, startCol=1, endCol=10, header=TRUE)
names(xls)

old_names = xls$Beast2.names
new_names = xls$Names_for_BGB

#outfn = change_tipnames_in_treefile(file=orig_nex_fn, old_names, new_names, outfn=NULL)
tmp_names = tr$tip.label
tmp_names_revised = tmp_names
for (i in 1:length(tmp_names))
	{
	tmp_name = tmp_names[i]
	name_num = which(old_names == tmp_name)
	if (length(name_num) > 0)
		{
		tmp_names_revised[i] = new_names[name_num]
		}
	} # END for (i in 1:nrow(tipranges@df))

cbind(tmp_names, tmp_names_revised)

tr$tip.label = tmp_names_revised
write.tree(tr, file=new_trfn)


tr2 = drop.tip(tr, tip=c("dubia_RPCAP03_Geck1_h0", "CYsp_RPCAP03_ABTC79193_h0"))
# New Geog file
new_trfn2 = gsub(pattern=".newick", replacement="_noOutgroups.newick", x=new_trfn)

write.tree(tr2, file=new_trfn2)

