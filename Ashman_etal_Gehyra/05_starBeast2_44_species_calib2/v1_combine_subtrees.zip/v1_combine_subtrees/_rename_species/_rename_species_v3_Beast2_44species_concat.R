library(XLConnect)
library(ape)
library(BioGeoBEARS)
source('/drives/GDrive/__github/BEASTmasteR/R/tree_utils_v1.R', chdir = TRUE)

# Working directory
wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/"
setwd(wd)

# NEXUS file
orig_nex_fn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/04_Beast2_44_species_calib2/treeLog.mcc"

# New NEXUS file
new_nex_fn = gsub(pattern=".mcc", replacement="_newNames.mcc", x=orig_nex_fn)


#######################################################
# Names in Excel file
#######################################################
# Excel workbook with old and new names
xls_fn = "BioGeoBEARS_coding_varpunc_biome_region_habitat_v3.xlsx"

xls = readWorksheetFromFile(file=xls_fn, sheet=1, startRow=1, endRow=45, startCol=1, endCol=10, header=TRUE)
names(xls)

old_names = xls$Beast2.names
new_names = xls$Names_for_BGB

outfn = change_tipnames_in_treefile(file=orig_nex_fn, old_names, new_names, outfn=new_nex_fn)

tr2 = read.nexus(outfn)
tr2

plot(tr2)
axisPhylo()

tr = read.nexus(orig_nex_fn)
tr

plot(tr)
axisPhylo()
