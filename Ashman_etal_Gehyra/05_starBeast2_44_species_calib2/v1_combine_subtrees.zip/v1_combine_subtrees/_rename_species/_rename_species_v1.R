library(XLConnect)
library(ape)
library(BioGeoBEARS)

# Working directory
wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/"
setwd(wd)

# NEXUS file
orig_nex_fn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/merged_trees_v1.mcc"

# New NEXUS file
new_nex_fn = gsub(pattern=".mcc", replacement="_newNames.mcc", x=orig_nex_fn)


#######################################################
# Names in Excel file
#######################################################
# Excel workbook with old and new names
xls_fn = "Ashman_etal_NEW_NAMES.xlsx"

xls = readWorksheetFromFile(file=xls_fn, sheet=2, startRow=1, endRow=45, startCol=1, endCol=5, header=TRUE)
names(xls)

old_names = xls$Current.names
new_names = xls$Names.for.paper


#######################################################
# Names in NEXUS file
#######################################################
moref(orig_nex_fn)

# Get the tipnames in the original tree
tr = read.nexus(orig_nex_fn)
tipnames = tr$tip.label

# Sort labels by size (change the longer names first)
# This helps if e.g. we have old names nana, nana4, nana45, etc.
name_lengths = nchar(old_names)

old_names_sort = old_names[rev(order(name_lengths))]
old_names_sort
new_names_sort = new_names[rev(order(name_lengths))]
new_names_sort

# Does everything match?
tipnames %in% old_names_sort
old_names_sort %in% tipnames_sort


#######################################################
# Go through the text of the NEXUS file and rename
#######################################################
tmplines = readLines(con=orig_nex_fn)

for (j in 1:length(old_names_sort))
	{
	old_tipname = old_names_sort[j]
	new_tipname = new_names_sort[j]
	for (i in 1:length(tmplines))
		{
		tmplines[i] = gsub(pattern=old_tipname, replacement=new_tipname, x=tmplines[i])
		} # END for (i in 1:length(tmplines))
	} # END for (j in 1:length(old_names_sort))

# Write out to new file
writeLines(text=tmplines, con=new_nex_fn, sep="\n")


