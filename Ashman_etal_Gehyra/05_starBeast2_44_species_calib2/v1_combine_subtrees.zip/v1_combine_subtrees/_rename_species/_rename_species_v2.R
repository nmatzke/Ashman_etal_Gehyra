library(XLConnect)
library(ape)
library(BioGeoBEARS)
source('/drives/GDrive/__github/BEASTmasteR/R/tree_utils_v1.R', chdir = TRUE)

# Working directory
wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/_rename_species/"
setwd(wd)

# NEXUS file
orig_nex_fn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/v1_combine_subtrees/merged_trees_v1.mcc"

# New NEXUS file
new_nex_fn = gsub(pattern=".mcc", replacement="_newNames.mcc", x=orig_nex_fn)


#######################################################
# Names in Excel file
#######################################################
# Excel workbook with old and new names
xls_fn = "Ashman_etal_NEW_NAMES.xlsx"

xls = readWorksheetFromFile(file=xls_fn, sheet=2, startRow=1, endRow=45, startCol=1, endCol=5, header=TRUE)
names(xls)

old_names = xls$Current.names
new_names = xls$Names.for.paper

outfn = change_tipnames_in_treefile(file=orig_nex_fn, old_names, new_names, outfn=NULL)

tr2 = read.nexus(outfn)
tr2

plot(tr2)
axisPhylo()

tr = read.nexus(orig_nex_fn)
tr

plot(tr)
axisPhylo()
