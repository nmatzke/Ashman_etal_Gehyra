# Run r8s
library(ape)

sourcedir = '/drives/Dropbox/_njm/'
source3 = '_genericR_v1.R'
source(paste(sourcedir, source3, sep=""))

source3 = '_R_tree_functions_v1.R'
source(paste(sourcedir, source3, sep=""))

# R functions for interacting with r8s (Sanderson 200x)
# Load with:
source3 = 'r8s_functions_v1.R'
source(paste(sourcedir, source3, sep=""))

library(phangorn)  # helps with "midpoint" function
#library(picante)  # for "Kcalc" and "phylosignal", i.e. calculation of the kappa statistic for continuous parameters
library(phylobase)
library(BioGeoBEARS)

wd = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/03_r8s_44species_calib2/"
setwd(wd)

molecular_trfn = "/drives/GDrive/__GDrive_projects/2016-07-31_divide_and_conquer_starBEAST/05_Gehyra_106_loci/02_RAxML_bootstrap_44species/ML_tree_w_bootstraps.newick"
molecular_tr = read.tree(molecular_trfn)
plot(molecular_tr)
molecular_tr_table = prt(molecular_tr, printflag=FALSE, get_tipnames=TRUE)






trfn = "ML_tree_w_bootstraps.newick"
tr = read.tree(trfn)
tr = ladderize(tr, right=FALSE)
plot(tr)



# Re-root
# outgroup_tips = c("Gdubia_1", "Gcysp_1")
# mrca_node = getMRCA(phy=tr, tip=outgroup_tips)
# tr2 = root(tr, outgroup=outgroup_tips)
# plot(tr2)
# 
# # Drop those outgroup tips since they are not e.g. midpoint-rooted
# tr3 = drop.tip(tr2, tip=outgroup_tips)
# tr4 = read.tree(file="", text=write.tree(tr3, file=""))
tr4 = tr

# 2017-04-20
# Nick try - 
# Clade defined by dubia-variegataA
# Mean 19.1 (13.2-26.0)
calibration_node_tip_specifiers = c("dubia_RPCAP03_Geck1_h0", "variegata_LA01_WAM117025_h0")

#######################################################
# Error check
#######################################################
if ( any((calibration_node_tip_specifiers %in% tr4$tip.label) == FALSE) )
	{
	stop("STOP ERROR: All calibration_node_tip_specifiers must be in the tree tip labels.")
	}

# tr = tr4

numsites = 31383
numsites

# color the branches with the rates
# Molecular tree
runpdf = TRUE
if (runpdf)
	{
	pdffn="Gehyra_106loci_RAxML.pdf"
	pdf(file=pdffn, width=10, height=15)
	}
#drawtree_branches_bluered(tr, tr$edge.length, titletxt="Edge lengths")
plot(tr4, edge.width=4, edge.color="darkgrey", label.offset=0.005)
title("Gehyra, 106 loci concat RAxML, 44 species\nMolecular tree")

logfn = run_r8s_1calib(tr, calibration_node_tip_specifiers, calibration_age=19.1, nsites=30000)
moref(logfn)

lftr = extract_tree_from_r8slog(logfn)
#plot(lftr)
rates_dtf = extract_rates_from_r8slog2(logfn="r8s_nexus_fn.nex.log")
rates_dtf
(summary_rate_variation = get_summary_rate_variation(rates_dtf))
rates_for_edges = rates_dtf$Local
rates_for_edges = rates_for_edges[is.not.na(rates_for_edges)]
rates_for_edges = lftr$edge.length/tr$edge.length
drawtree_branches_bluered(lftr, rates_for_edges, titletxt="Rescaled/original ratio")
title("r8s, Langley-Fitch")

# Repeat with axisPhylo()
drawtree_branches_bluered(lftr, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat RAxML, 44 species\nr8s, Langley-Fitch")
axisPhylo()
write.tree(lftr, file="Langley-Fitch_strict_clock_tree.newick")


logfn = run_r8s_1calib(tr, calibration_node_tip_specifiers, calibration_age=19.1, r8s_method="PL algorithm=tn", addl_cmd="set penalty=add;\nset smoothing=1;", nsites=numsites)
pltr1 = extract_tree_from_r8slog(logfn)
#plot(pltr1)
rates_dtf = extract_rates_from_r8slog2(logfn="r8s_nexus_fn.nex.log")
rates_dtf
(summary_rate_variation = get_summary_rate_variation(rates_dtf))
rates_for_edges = rates_dtf$Local
rates_for_edges = rates_for_edges[is.not.na(rates_for_edges)]
rates_for_edges = pltr1$edge.length/tr$edge.length
drawtree_branches_bluered(pltr1, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat RAxML, 44 species\nr8s, PL, smoothing=1")
axisPhylo()
write.tree(pltr1, file="PL_smoothing1_tree.newick")


logfn = run_r8s_1calib(tr, calibration_node_tip_specifiers, calibration_age=19.1, r8s_method="PL algorithm=tn", addl_cmd="set penalty=add;\nset smoothing=10;", nsites=numsites)
pltr2 = extract_tree_from_r8slog(logfn)
#plot(pltr2)
rates_dtf = extract_rates_from_r8slog2(logfn="r8s_nexus_fn.nex.log")
rates_dtf
(summary_rate_variation = get_summary_rate_variation(rates_dtf))
rates_for_edges = rates_dtf$Local
rates_for_edges = rates_for_edges[is.not.na(rates_for_edges)]
rates_for_edges = pltr2$edge.length/tr$edge.length
drawtree_branches_bluered(pltr2, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat RAxML, 44 species\nr8s, PL, smoothing=10")
axisPhylo()
write.tree(pltr2, file="PL_smoothing10_tree.newick")



logfn = run_r8s_1calib(tr, calibration_node_tip_specifiers, calibration_age=19.1, r8s_method="PL algorithm=tn", addl_cmd="set penalty=add;\nset smoothing=100;", nsites=numsites)
pltr3 = extract_tree_from_r8slog(logfn)
#plot(pltr3)
rates_dtf = extract_rates_from_r8slog2(logfn="r8s_nexus_fn.nex.log")
rates_dtf
(summary_rate_variation = get_summary_rate_variation(rates_dtf))
rates_for_edges = rates_dtf$Local
rates_for_edges = rates_for_edges[is.not.na(rates_for_edges)]
rates_for_edges = pltr3$edge.length/tr$edge.length
drawtree_branches_bluered(pltr3, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat RAxML, 44 species\nr8s, PL, smoothing=100")
axisPhylo()
write.tree(pltr3, file="PL_smoothing1000_tree.newick")


# Error with NPRS:
# # Only method=LF or PL currently allowed
# logfn = run_r8s_1calib(tr, calibration_node_tip_specifiers, r8s_method="NPRS")
# nprstr = extract_tree_from_r8slog(logfn)
# plot(nprstr)
# rates_dtf = extract_rates_from_r8slog2(logfn="r8s_nexus_fn.nex.log")
# rates_dtf
# (summary_rate_variation = get_summary_rate_variation(rates_dtf))
# rates_for_edges = rates_dtf$Local
# rates_for_edges = rates_for_edges[is.not.na(rates_for_edges)]
# rates_for_edges = nprstr$edge.length/tr$edge.length
# drawtree_branches_bluered(nprstr, rates_for_edges, titletxt="Rescaled/original ratio")
# title("r8s, NPRS")





# Scaled trees
# chtr2 = chronogram(tr)
# rates_for_edges = chtr2$edge.length/tr$edge.length
# drawtree_branches_bluered(chtr2, rates_for_edges, titletxt="Rescaled/original ratio")
# title("Gehyra, 106 loci concat, 44 species
#R: chronogram")

chtr3 = chronopl(tr, lambda=0)
rates_for_edges = chtr3$edge.length/tr$edge.length
drawtree_branches_bluered(chtr3, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat RAxML, 44 species\nR: chronopl, lambda=0")
axisPhylo()

chtr4 = chronopl(tr, lambda=1)
rates_for_edges = chtr4$edge.length/tr$edge.length
drawtree_branches_bluered(chtr4, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat, 44 species\nR: chronopl, lambda=1")
axisPhylo()

chtr5 = chronopl(tr, lambda=2)
rates_for_edges = chtr5$edge.length/tr$edge.length
drawtree_branches_bluered(chtr5, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat, 44 species\nR: chronopl, lambda=2")
axisPhylo()

chtr6 = chronopl(tr, lambda=10)
rates_for_edges = chtr6$edge.length/tr$edge.length
drawtree_branches_bluered(chtr6, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat, 44 species\nR: chronopl, lambda=10")
axisPhylo()

chtr7 = chronopl(tr, lambda=100)
rates_for_edges = chtr7$edge.length/tr$edge.length
drawtree_branches_bluered(chtr7, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat, 44 species\nR: chronopl, lambda=100")
axisPhylo()

chtr8 = chronopl(tr, lambda=1000)
rates_for_edges = chtr8$edge.length/tr$edge.length
drawtree_branches_bluered(chtr8, rates_for_edges, titletxt="Rescaled/original ratio")
title("Gehyra, 106 loci concat, 44 species\nR: chronopl, lambda=1000")
axisPhylo()


if (runpdf)
	{
	dev.off()
	cmdstr = paste("open ", pdffn, sep="")
	system(cmdstr)
	}


#######################################################
# Plot the strict clock tree
#######################################################
trfn = "Langley-Fitch_strict_clock_tree.newick"
pdffn = "Langley-Fitch_strict_clock_tree.newick.pdf"
pdf(file=pdffn, width=8.5, height=11)

strict_tr = read.tree(trfn)
plot(ladderize(strict_tr, right=FALSE))
axisPhylo()
title("Gehyra, 44 species, 106 loci concat\nRAxML->r8s strict clock")

strict_tr_table = prt(strict_tr, printflag=FALSE, get_tipnames=TRUE)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)




#######################################################
# Plot the strict clock tree, with bootstraps
#######################################################
# tree with bootstraps
molecular_tr = read.tree(molecular_trfn)
plot(tr)
molecular_tr_table 

# Ladderize the tree FIRST
strict_tr_ladderized = ladderize(strict_tr, right=FALSE)
strict_tr_ladderized$node.label
strict_tr_ladderized = read.tree(file="", text=write.tree(strict_tr_ladderized, file=""))

# Match nodes, put in labels
internal_nodenums = (length(strict_tr_ladderized$tip.label)+1):(length(strict_tr_ladderized$tip.label)+strict_tr_ladderized$Nnode)
internal_nodenums

strict_tr_ladderized_table = prt(strict_tr_ladderized, printflag=FALSE, get_tipnames=TRUE)
for (i in 1:length(internal_nodenums))
	{
	internal_nodenum = internal_nodenums[i]
	tip_taxa_txt = strict_tr_ladderized_table$tipnames[internal_nodenum]
	TF = molecular_tr_table$tipnames %in% tip_taxa_txt
	if (sum(TF) == 1)
		{
		strict_tr_ladderized_table$label[internal_nodenum] = molecular_tr_table$label[TF]
		} else {
		strict_tr_ladderized_table$label[internal_nodenum] = ""
		}
	}

# Put in the tree
strict_tr_ladderized$node.label = strict_tr_ladderized_table$label[internal_nodenums]
strict_tr_ladderized$node.label 

# Edges
edges_to_plot_on = strict_tr_ladderized_table$parent_br[internal_nodenums]


# Plot with edge labels
out_newick_fn = "Langley-Fitch_strict_clock_tree_wBootstraps.newick"
write.tree(strict_tr_ladderized, file=out_newick_fn)

pdffn = "Langley-Fitch_strict_clock_tree_wBootstraps.newick.pdf"
pdf(file=pdffn, width=8.5, height=11)

plot(strict_tr_ladderized)
axisPhylo()
title("Gehyra, 44 species, 106 loci concat\nRAxML->r8s strict clock\nladderized, with bootstraps")
edgelabels(text=strict_tr_ladderized$node.label, edges_to_plot_on, adj=c(0.5,0), frame="none", cex=0.75)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)


# 
# old2new_nodes_table = nodenums_bottom_up(nprstr)
# plot(nprstr)
# #rates_for_edges = rates_dtf$Local[old2new_nodes_table$LR_nodenums]
# rates_for_edges = rates_dtf$Local
# rates_for_edges = rates_for_edges[is.not.na(rates_for_edges)]
# edgelabels(rates_for_edges)


#tr_w_labels = makeNodeLabel(tr, method='number', prefix="Node")
#prt(tr_w_labels)

# not as good as extract_rates_from_r8slog2
#rates_data = extract_rates_from_r8slog(logfn="r8s_nexus_fn.nex.log")
#rates_data


